![Github Releases (by Release)](https://img.shields.io/github/downloads/xpack-dev-tools/openocd-xpack/v{{ XBB_RELEASE_VERSION }}/total.svg)

Version **{{ XBB_RELEASE_VERSION }}** is a maintenance release of the **xPack OpenOCD** package; it updates to the latest upstream master.

Or (TODO: edit!):

Version **{{ XBB_RELEASE_VERSION }}** is a new release of the **xPack OpenOCD** package, following the upstream OpenOCD release.

[Continue reading »](TODO: edit, add URL!)

_At this moment the binaries are provided for tests only!_
